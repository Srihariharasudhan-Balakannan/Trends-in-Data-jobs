# imports
import streamlit_app as app

if __name__ == '__main__':
    # run app 
    app.run()